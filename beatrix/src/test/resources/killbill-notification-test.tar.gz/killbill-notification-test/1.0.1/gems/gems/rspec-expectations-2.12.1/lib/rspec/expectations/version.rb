module RSpec
  module Expectations
    # @private
    module Version
      STRING = '2.12.1'
    end
  end
end
