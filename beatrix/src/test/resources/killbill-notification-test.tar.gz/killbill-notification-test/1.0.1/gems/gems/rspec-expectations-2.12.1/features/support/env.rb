require 'aruba/cucumber'

Before do
  @aruba_timeout_seconds = 15
end
